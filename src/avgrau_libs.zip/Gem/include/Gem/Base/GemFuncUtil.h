#ifdef __GNUC__
# warning GemFuncUtil.h is deprecated - please include "Utils/Functions.h" instead
#endif
#include "Utils/Functions.h"
