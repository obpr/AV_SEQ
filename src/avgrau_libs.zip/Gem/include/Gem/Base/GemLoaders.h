#ifdef __GNUC__
# warning Base/GemLoaders.h is deprecated - please include "Gem/Loaders.h" instead
#endif
#include "Gem/Loaders.h"
