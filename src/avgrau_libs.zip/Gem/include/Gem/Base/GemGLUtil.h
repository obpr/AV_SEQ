#ifdef __GNUC__
# warning GemGLUtil.h is deprecated - please include "Utils/GLUtil.h" instead
#endif
#include "Utils/GLUtil.h"
