#ifdef __GNUC__
# warning GemMath.h is deprecated - please include "Utils/Math.h" instead
#endif
#include "Utils/Math.h"
