#ifdef __GNUC__
# warning GemMan.h is deprecated - please include "Gem/Manager.h" instead
#endif
#include "Gem/Manager.h"
