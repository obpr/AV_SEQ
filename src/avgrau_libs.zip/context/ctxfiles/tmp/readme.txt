This folder contains temporary files used in overlay saving. Every time the overlay is saved, a new file is created. It is safe to delete these files at any time.
